# Cara Setting Tampilan Depan Termux Menjadi Lebih Keren
Alat untuk mengubah tampilan depan termux atau bilah alat termux menjadi lebih keren coba kalian unduh dulu aplikasi termux nya di play store gratis yang lalu kalau sudah kalian harus menginstal bahan2 nya dulu di aplikasi termux nya 
bahan2 nya adalah:


# $ apt update && apt upgrade
# $ pkg install figlet
# $ pkg install lolcat
# $ pkg install python2
# $ pkg install bash

jika bahan-bahan di atas sudah terinstall kalian ketikan eksekusi caranya.
caranya adalah:

# $ pkg install git
# $ git clone https://github.com/Rusmana-ID/home-termux
# $ cd home-termux
# $ ls
# $ python2 run.py

tunggu prosess nya sampai selesai.
jika sudah selesai langkah selanjutnya adalah nanti di termux nya akan muncul tulisan "ketikan Ctrl +d"
nah untuk menampilkan tombol special di termux yaitu seperti ctrl, home, dll caranya kalian
tekan voleme up +q secara bersamaan maka akan muncul tombol specialnya di termux
terus jika sudah muncul ctrl nya kalian tinggal klik ctrl nya terus klik d terus enter
lalu kembali lagi ke aplikasi termux nya dan lihat hasilnya ...


